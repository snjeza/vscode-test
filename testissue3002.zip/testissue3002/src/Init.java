public interface Init<C extends Configuration> {
}
