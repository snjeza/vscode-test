public @interface Annot {
    Class<? extends Init<? extends Configuration>>[] inits(); 
}