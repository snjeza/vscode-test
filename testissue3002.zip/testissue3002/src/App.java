interface I<T> {}
class IImpl<T> implements I<String>, Init<Configuration> {}
@Annot(inits = {App.MyInit.class})
public class App {
	static class MyInit extends IImpl<Configuration> {}
}
